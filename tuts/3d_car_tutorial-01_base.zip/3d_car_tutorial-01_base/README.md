# 3d_car_tutorial
Making a 3D kinematic car in Godot.
